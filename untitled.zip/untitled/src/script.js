// Activity Data (can be replaced with JSON or localStorage)
let activities = [
    { id: 1, name: "Wake up early", completed: false },
    { id: 2, name: "Exercise", completed: false },
    { id: 3, name: "Read a book", completed: false },
    { id: 4, name: "Complete assignment", completed: false },
    { id: 5, name: "Practice coding", completed: false }
];

// Get DOM elements
const activityList = document.getElementById("activityList");
const progressText = document.getElementById("progress");

// Render Activities
function renderActivities() {
    activityList.innerHTML = "";

    activities.forEach(activity => {
        const li = document.createElement("li");

        // Apply completed style
        if (activity.completed) {
            li.classList.add("completed");
        }

        li.innerHTML = `
            <span>${activity.name}</span>
            <button onclick="toggleComplete(${activity.id})">
                ${activity.completed ? "Undo" : "Complete"}
            </button>
        `;

        activityList.appendChild(li);
    });

    updateProgress();
}

// Toggle activity status
function toggleComplete(id) {
    activities = activities.map(activity => {
        if (activity.id === id) {
            return { ...activity, completed: !activity.completed };
        }
        return activity;
    });

    renderActivities();
}

// Update progress
function updateProgress() {
    const completedCount = activities.filter(a => a.completed).length;
    const total = activities.length;

    progressText.textContent = `${completedCount} out of ${total} activities completed`;
}

// Initial render
renderActivities();